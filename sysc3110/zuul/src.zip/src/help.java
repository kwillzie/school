
public class help extends Command{
	
	public help(String firstWord, String secondWord){
		super(firstWord, secondWord);
	}
	
	public void act(){
		
		
	}
}
