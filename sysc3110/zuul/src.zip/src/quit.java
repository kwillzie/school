
public class quit extends Command{
	
	public quit(String firstWord, String secondWord){
		super(firstWord, secondWord);
	}
	
	public void act(){
		
		
	}
}
