
public class look extends Command{
	
	public look(String firstWord, String secondWord){
		super(firstWord, secondWord);
	}
	
	public void act(){
		
		
	}
}
